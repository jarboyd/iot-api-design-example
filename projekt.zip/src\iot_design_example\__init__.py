from multiprocessing import Process

from iot_design_example.consumers import (
    MonitorConsumer,
    AnomalyConsumer,
    AlarmConsumer,
    SensorAggregationMaxTemperatureConsumer,
    SensorAggregationAvgTemperatureConsumer,
)
from iot_design_example.infra import Connection, declare_exchanges, declare_alarm_queue
from iot_design_example.producers import (
    MockHumidityProducer,
    MockPressureProducer,
    MockTemperatureProducer,
    RoutingKey,
)


def run_mock_temperature_sensor():
    with Connection() as connection:
        channel = connection.channel()
        declare_exchanges(channel)

        producer = MockTemperatureProducer(channel)
        producer.start_producing()


def run_mock_pressure_sensor():
    with Connection() as connection:
        channel = connection.channel()
        declare_exchanges(channel)

        producer = MockPressureProducer(channel)
        producer.start_producing()


def run_mock_humidity_sensor():
    with Connection() as connection:
        channel = connection.channel()
        declare_exchanges(channel)

        producer = MockHumidityProducer(channel)
        producer.start_producing()


def run_monitor_consumer():
    with Connection() as connection:
        channel = connection.channel()
        declare_exchanges(channel)

        consumer = MonitorConsumer(channel)
        consumer.start_consuming()


def run_anomaly_consumer(routing_key: RoutingKey):
    with Connection() as connection:
        channel = connection.channel()
        declare_exchanges(channel)

        consumer = AnomalyConsumer(channel, routing_key)
        consumer.start_consuming()

def run_alarm_consumer():
    with Connection() as connection:
        channel = connection.channel()
        declare_exchanges(channel)
        declare_alarm_queue(channel)

        consumer = AlarmConsumer(channel)
        consumer.start_consuming()


def run_max_aggregation_consumer():
    with Connection() as connection:
        channel = connection.channel()
        declare_exchanges(channel)

        consumer = SensorAggregationMaxTemperatureConsumer(channel)
        consumer.start_consuming()

def run_avg_aggregation_consumer():
    with Connection() as connection:
        channel = connection.channel()
        declare_exchanges(channel)

        consumer = SensorAggregationAvgTemperatureConsumer(channel)
        consumer.start_consuming()


def main() -> None:
    consumers = [
        Process(target=run_monitor_consumer), 
        Process(target=run_alarm_consumer),
        Process(
            target=run_anomaly_consumer,
            args=(RoutingKey.sensor_temperature,),
        ),
        Process(
            target=run_anomaly_consumer,
            args=(RoutingKey.sensor_pressure,),
        ),
        Process(target=run_max_aggregation_consumer),
        Process(target=run_avg_aggregation_consumer),
    ]
    producers = [
        Process(target=run_mock_temperature_sensor),
        Process(target=run_mock_pressure_sensor),
        Process(target=run_mock_humidity_sensor),
    ]

    print("Starting consumers")
    for p in consumers:
        p.start()
    print("Starting producers")
    for p in producers:
        p.start()
    print("Consumers and producers running")
    for p in producers + consumers:
        p.join()
    print("All processes have finished.")

if __name__ == "__main__":
    main()